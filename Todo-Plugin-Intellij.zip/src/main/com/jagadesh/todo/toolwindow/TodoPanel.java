package com.jagadesh.todo.toolwindow;

import com.intellij.openapi.editor.Editor;
import com.intellij.openapi.fileEditor.FileEditorManager;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.vfs.VirtualFile;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TodoPanel {
    private JPanel mainPanel;
    private JList<String> todoList;
    private DefaultListModel<String> listModel;
    private Project project;

    public TodoPanel(Project project) {
        this.project = project;
        listModel = new DefaultListModel<>();
        todoList = new JList<>(listModel);
        mainPanel = new JPanel(new BorderLayout());
        mainPanel.add(new JScrollPane(todoList), BorderLayout.CENTER);

        refreshTodos();
    }

    private void refreshTodos() {
        Editor editor = FileEditorManager.getInstance(project).getSelectedTextEditor();
        if (editor == null) return;

        VirtualFile file = FileEditorManager.getInstance(project).getSelectedFiles()[0];
        listModel.clear();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            int lineNumber = 0;
            Pattern pattern = Pattern.compile(".*TODO.*");

            while ((line = reader.readLine()) != null) {
                Matcher matcher = pattern.matcher(line);
                if (matcher.find()) {
                    listModel.addElement("Line " + (lineNumber + 1) + ": " + line.trim());
                }
                lineNumber++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public JPanel getContent() {
        return mainPanel;
    }
}
